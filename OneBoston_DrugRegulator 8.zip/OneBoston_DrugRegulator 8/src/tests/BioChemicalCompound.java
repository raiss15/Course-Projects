/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tests;

/**
 *
 * @author bhagyatrivedi
 */
public class BioChemicalCompound {
    private String bioChemicalCompound;
    

    public String getBioChemicalCompound() {
        return bioChemicalCompound;
    }

    public void setBioChemicalCompound(String bioChemicalCompound) {
        this.bioChemicalCompound = bioChemicalCompound;
    } 
    
}
