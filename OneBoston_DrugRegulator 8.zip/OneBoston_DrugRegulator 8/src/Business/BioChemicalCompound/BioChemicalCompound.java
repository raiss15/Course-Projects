/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.BioChemicalCompound;

/**
 *
 * @author sohni
 */
public class BioChemicalCompound {
    private String bioChemicalCompound;
    

    public String getBioChemicalCompound() {
        return bioChemicalCompound;
    }

    public void setBioChemicalCompound(String bioChemicalCompound) {
        this.bioChemicalCompound = bioChemicalCompound;
    } 
    
}
